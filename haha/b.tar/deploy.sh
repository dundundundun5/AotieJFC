#!/bin/bash
echo "START CLEAR"
docker stop    $(docker ps -a | grep train-risk-detect-2 | awk '{print $1}')
docker rm -f   $(docker ps -a | grep train-risk-detect-2 | awk '{print $1}')
docker rmi -f $(docker images | grep train-risk-detect-2 | awk '{print $3}')

echo "START BUILD"
docker build --network=host -t train-risk-detect-2 .

echo "START RUN"
docker run --restart=always --gpus '"device=1"' --net host -e TZ=Asia/Shanghai -d -p 8091:8091 \
-v /data:/data \
--name train-risk-detect-2 train-risk-detect-2:latest


