import os
import sys


def is_debug_mode():
    if 'PYDEVD_DEBUG' in os.environ:
        return True
    gettrace = getattr(sys, 'gettrace', None)
    if gettrace and gettrace() is not None:
        return True

    return False


def torch_cuda_is_available():
    import torch
    print("use cuda: ", torch.cuda.is_available())


torch_cuda_is_available()
