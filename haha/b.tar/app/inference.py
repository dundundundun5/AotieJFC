from concurrent.futures import ThreadPoolExecutor

import cv2
import numpy as np
import torch
from ultralytics import YOLO

from configs import config


def is_contour_straight(contour, threshold=20):
    points = contour.squeeze(axis=1)
    if len(points) < 2:
        return False

    x = points[:, 0]
    y = points[:, 1]

    A = np.vstack([x, np.ones(len(x))]).T
    k, b = np.linalg.lstsq(A, y, rcond=None)[0]

    distances = np.abs(k * x - y + b) / np.sqrt(k ** 2 + 1)
    mean_distance = np.mean(distances)

    return mean_distance <= threshold


class Inference(object):
    def __init__(self,
                 model_path: str,
                 input_size: tuple = (640, 640),
                 conf: float = 0.5,
                 iou: float = 0.3,
                 task: str = 'segment'):
        self.model = YOLO(model=model_path, task=task)
        self.model(np.zeros((input_size[1], input_size[0], 3), dtype=np.uint8))
        self.input_size = input_size
        self.conf = conf
        self.iou = iou
        self.task = task
        self.executor = ThreadPoolExecutor(max_workers=4)

    def predict_cls(self, image):
        results = self.model(source=image, conf=self.conf)

        defects = []
        for result in results:
            probs = result.probs
            top1_idx = probs.argmax()
            top1_conf = probs[top1_idx].item()
            defect = {
                "defectType": result.names[top1_idx],
                "defectScore": round(top1_conf, 4),
            }
            defects.append(defect)

        torch.cuda.empty_cache()
        return defects

    def predict_det(self, image):
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image

        results = self.model(source=image, conf=self.conf, iou=self.iou, imgsz=self.input_size, verbose=False)

        defects = []
        for result in results:
            if not hasattr(result, 'boxes'):
                continue

            for box in result.boxes:
                cls = int(box.cls)
                conf = box.conf.item()
                xyxy = box.xyxy.squeeze().tolist()

                width = xyxy[2] - xyxy[0]
                height = xyxy[3] - xyxy[1]
                area = width * height

                x1, y1, x2, y2 = map(int, [xyxy[0], xyxy[1], xyxy[2], xyxy[3]])
                roi = gray[y1:y2, x1:x2]
                mean_value = np.mean(roi) if roi.size > 0 else 0

                defect = {
                    "defectType": result.names[cls],
                    "defectScore": round(conf, 4),
                    "topLeft": {"x": xyxy[0], "y": xyxy[1]},
                    "bottomRight": {"x": xyxy[2], "y": xyxy[3]},
                    "defectArea": int(area),
                    "defectValue": int(mean_value)
                }
                defects.append(defect)

        torch.cuda.empty_cache()
        return defects

    def predict_seg(self, image):
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
        else:
            gray = image

        ori_h, ori_w = image.shape[:2]
        results = self.model(source=image, conf=self.conf, iou=self.iou, imgsz=self.input_size, verbose=False)

        defects = []
        for result in results:
            if not hasattr(result, 'boxes') or not hasattr(result, 'masks'):
                continue

            boxes = result.boxes
            masks = result.masks.xy if hasattr(result.masks, 'xy') else []
            for box, mask in zip(boxes, masks):
                cls = int(box.cls)
                conf = float(box.conf)
                label = result.names[cls].replace('PBF', 'PB').replace('ZJF', 'ZJ')
                min_score = config.get(label, 0.5)
                if conf < min_score: continue

                xyxy = box.xyxy.squeeze().tolist()
                x, y, w, h = int(xyxy[0]), int(xyxy[1]), int(xyxy[2] - xyxy[0] + 1), int(xyxy[3] - xyxy[1] + 1)
                margin = config.get('RISK_MARGIN', 5)
                if x < margin or x + w - 1 > ori_w - 1 - margin: continue

                if result.names[cls] in ['SL', 'Z', 'JGQ', 'HX', 'RG', 'ZL']:  # 下
                    if y + h < ori_h // 2: continue
                elif result.names[cls] in ['PB', 'P', 'M', 'ZJ']:  # 上
                    if y > ori_h // 2: continue

                # 计算分割区域面积
                contour = mask.reshape((-1, 1, 2)).astype(np.int32)
                area = cv2.contourArea(contour)

                # 创建掩码并计算平均亮度
                mask_img = np.zeros(gray.shape[:2], dtype=np.uint8)
                cv2.fillPoly(mask_img, [contour], 1)
                mean_value = cv2.mean(gray, mask=mask_img)[0]

                defect = {
                    "defectType": label,
                    "defectScore": round(conf, 4),
                    "topLeft": {"x": xyxy[0], "y": xyxy[1]},
                    "bottomRight": {"x": xyxy[2], "y": xyxy[3]},
                    "defectArea": int(area),
                    "defectValue": int(mean_value)
                }
                defects.append(defect)

        torch.cuda.empty_cache()
        return defects

    def __call__(self, image):
        if self.task == 'segment':
            return self.predict_seg(image)
        elif self.task == 'classify':
            return self.predict_cls(image)
        return self.predict_det(image)


class InferenceLoadModelCache:
    instance = None


class InferenceBodyModelCache:
    instance = None


class InferenceTrilModelCache:
    instance = None


def get_inference_load_model():
    if InferenceLoadModelCache.instance is None:
        InferenceLoadModelCache.instance = Inference(
            model_path="/data/weights/train-load-segment-2.pt",
            input_size=(1280, 1280),
            conf=config['load_conf'],
            iou=config['load_iou'],
            task='segment'
        )
    return InferenceLoadModelCache.instance


def get_inference_body_model():
    if InferenceBodyModelCache.instance is None:
        InferenceBodyModelCache.instance = Inference(
            model_path="/data/weights/train-body-segment-2.pt",
            input_size=(1280, 1280),
            conf=config['body_conf'],
            iou=config['body_iou'],
            task='segment'
        )
    return InferenceBodyModelCache.instance


def get_inference_tril_model():
    if InferenceTrilModelCache.instance is None:
        InferenceTrilModelCache.instance = Inference(
            model_path="/data/weights/train-tril-segment-2.pt",
            input_size=(1280, 1280),
            conf=config['tril_conf'],
            iou=config['tril_iou'],
            task='segment'
        )
    return InferenceTrilModelCache.instance
