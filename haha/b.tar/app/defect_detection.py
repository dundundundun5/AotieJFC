from concurrent.futures import ThreadPoolExecutor

import numpy as np

from app.inference import get_inference_load_model, get_inference_body_model, get_inference_tril_model


def warmup_model():
    inference_load = get_inference_load_model()
    inference_load(np.zeros((1280, 1280, 3), dtype=np.uint8))
    inference_body = get_inference_body_model()
    inference_body(np.zeros((1280, 1280, 3), dtype=np.uint8))
    inference_tril = get_inference_tril_model()
    inference_tril(np.zeros((1280, 1280, 3), dtype=np.uint8))


def _process_load_task(img, crop_position='RIGHT'):
    ori_h, ori_w = img.shape[:2]
    defects = []

    try:
        if crop_position == 'RIGHT':
            x1, x2, y1, y2 = ori_w - ori_h, ori_w, 0, ori_h
            inference_tril = get_inference_tril_model()
            defects = inference_tril(img[y1:y2, x1:x2])
            defects = [d for d in defects if d['defectType'] in ['BT', 'Z']]
            for d in defects:
                d["topLeft"]['x'] = x1 + d["topLeft"]['x']
                d["bottomRight"]['x'] = x1 + d["bottomRight"]['x']
        elif crop_position == 'LEFT':
            x1, x2, y1, y2 = 0, ori_h, 0, ori_h
            inference_tril = get_inference_tril_model()
            defects = inference_tril(img[y1:y2, x1:x2])
            defects = [d for d in defects if d['defectType'] in ['BT']]
            for d in defects:
                d["topLeft"]['x'] = x1 + d["topLeft"]['x']
                d["bottomRight"]['x'] = x1 + d["bottomRight"]['x']
        else:
            inference_load = get_inference_load_model()
            defects = inference_load(img)
            defects = [d for d in defects if d['defectType'] in ['PB', 'SL', 'YW', 'P', 'M', 'ZW']]

    except Exception as e:
        return {
            "code": 500,
            "message": str(e),
            "defects": defects
        }

    return defects


def _process_body_task(img, crop_position='LEFT'):
    ori_h, ori_w = img.shape[:2]
    defects = []

    try:
        if crop_position == 'LEFT':
            x1, x2, y1, y2 = 0, ori_h, 0, ori_h
            inference_tril = get_inference_tril_model()
            defects = inference_tril(img[y1:y2, x1:x2])
            defects = [d for d in defects if d['defectType'] in ['JGQ', 'ZJ']]
        elif crop_position == 'RIGHT':
            x1, x2, y1, y2 = ori_w - ori_h, ori_w, 0, ori_h
            inference_tril = get_inference_tril_model()
            defects = inference_tril(img[y1:y2, x1:x2])
            defects = [d for d in defects if d['defectType'] in ['RG']]
        else:
            inference_body = get_inference_body_model()
            defects = inference_body(img)
            defects = [d for d in defects if d['defectType'] in ['HX', 'RG', 'ZL']]

    except Exception as e:
        return {
            "code": 500,
            "message": str(e),
            "defects": defects
        }

    return defects


def defect_detection_text(img, task_name):
    ori_h, ori_w = img.shape[:2]

    try:
        if task_name not in ['LOAD', 'BODY', 'LEFT']:
            raise ValueError("Invalid task name")

        with ThreadPoolExecutor(max_workers=2) as executor:
            if task_name == 'LOAD':
                future_no_crop = executor.submit(_process_load_task, img, 'ALL')
                future_crop = executor.submit(_process_load_task, img, 'RIGHT')
                defects_no_crop = future_no_crop.result()
            elif task_name == 'BODY':
                future_no_crop = executor.submit(_process_body_task, img, 'ALL')
                future_crop = executor.submit(_process_body_task, img, 'LEFT')
                defects_no_crop = future_no_crop.result()
            elif task_name == 'LEFT':
                future_crop = executor.submit(_process_load_task, img, 'LEFT')
                defects_no_crop = []

            defects_crop = future_crop.result()

        defects = []
        if isinstance(defects_no_crop, list):
            defects.extend(defects_no_crop)
        if isinstance(defects_crop, list):
            defects.extend(defects_crop)

        return {
            'code': 200,
            'data': {
                'imageWidth': int(ori_w),
                'imageHeight': int(ori_h),
                'defectList': defects,
            }
        }
    except Exception as e:
        return {
            "code": 500,
            "message": str(e),
            "data": {
                "imageWidth": ori_w,
                "imageHeight": ori_h,
                "defectList": [],
            }
        }
