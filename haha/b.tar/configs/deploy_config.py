service_name = "train-risk-detect-2"
service_port = 8091

LOAD_NAMES = ['PB', 'SL', 'YW', 'P', 'M', 'ZW']
BODY_NAMES = ['JGQ', 'HX', 'RG', 'ZL', 'ZJ']
