import os
import glob
import shutil
import tqdm


def list_files(target_dir, pattern):
    return glob.glob(os.path.join(target_dir, pattern))


def batch_move_files_by_conference(from_dir, conference_dir, to_dir, from_predix=['.jpg'], conference_prefix='.jpg'):
    os.makedirs(to_dir, exist_ok=True)
    for prefix in from_predix:
        file_lists = list_files(from_dir, "*" + prefix)
        for file_list in tqdm.tqdm(file_lists):
            try:
                if os.path.exists(os.path.join(conference_dir,
                                               os.path.basename(file_list.replace(prefix, conference_prefix)))):
                    shutil.move(file_list, os.path.join(to_dir, os.path.basename(file_list)))
            except Exception as e:
                print('错误信息是：', e)
                continue


if __name__ == '__main__':
    from_folder = r'/data/images/test'
    to_folder = r'/data/images/test-To/'
    conference_folder = r'/data/images/test-Results/'
    batch_move_files_by_conference(from_folder, conference_folder, to_folder, ['.jpg', '.json'], '_result.jpg')
