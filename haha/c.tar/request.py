import glob
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import cv2
import requests
import tqdm

service_name = "train-ocr-detect-2"
service_port = 8092
colors = {
    'CZ': [255, 0, 0],
    'CH': [0, 255, 0]
}


def list_files(target_dir, pattern):
    return glob.glob(os.path.join(target_dir, pattern))


def list_dirs(target_dir):
    return [d for d in os.listdir(target_dir) if os.path.isdir(os.path.join(target_dir, d))]


def call_api(image_file):
    try:
        url = f"http://127.0.0.1:{service_port}/{service_name}/text/file"

        with open(image_file, 'rb') as f:
            files = {'image_file': (os.path.basename(image_file), f)}
            response = requests.post(url, files=files)
        if response.status_code == 200:
            return response.json()
        else:
            print(f"Request failed with status {response.status_code}: {response.text}")
            return None

    except Exception as e:
        print(f'API call error: {e}')
        return None


def show(image_file, result_dict):
    result_image = cv2.imread(image_file)
    if result_dict['data']["defectList"] and len(result_dict['data']['defectList']) > 0:
        for defect in result_dict["data"]["defectList"]:
            xmin = int(defect['topLeft']['x'])
            ymin = int(defect['topLeft']['y'])
            xmax = int(defect['bottomRight']['x'])
            ymax = int(defect['bottomRight']['y'])
            score = int(defect["defectScore"] * 100)

            cv2.rectangle(result_image, (xmin, ymin), (xmax, ymax), [255, 0, 255], 5)
            cv2.putText(result_image,
                        f"{defect['defectContent']}-{score}%",
                        (xmin, ymin - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 2, colors[defect['defectType']], 2)
    return result_image


def process_image(image_file, output_dir):
    try:
        output_path = os.path.join(
            output_dir,
            os.path.basename(image_file).replace('.jpg', '_result.jpg')
        )

        if os.path.exists(output_path):
            return

        start_time = time.time()
        result = call_api(image_file)

        if not result or 'data' not in result:
            print(f"No results for {image_file}")
            return

        print(f"处理耗时: {time.time() - start_time:.2f}s | {image_file}")
        result_image = show(image_file, result)
        cv2.imwrite(output_path, result_image)

    except Exception as e:
        print(f'处理失败: {e} | 文件: {image_file}')


def batch_predict(root_dir, output_root_dir):
    os.makedirs(output_root_dir, exist_ok=True)
    image_files = list_files(root_dir, "*.jpg")

    with ThreadPoolExecutor(max_workers=4) as executor:
        futures = [executor.submit(process_image, img, output_root_dir)
                   for img in image_files]

        for _ in tqdm.tqdm(as_completed(futures), total=len(futures)):
            pass


if __name__ == "__main__":
    image_folder = '/data/images/test'
    output_folder = '/data/images/test-Results/'
    s = time.time()
    batch_predict(image_folder, output_folder)
    print("total time: ", time.time() - s)
