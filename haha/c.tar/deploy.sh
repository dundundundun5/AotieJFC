#!/bin/bash
echo "START CLEAR"
docker stop    $(docker ps -a | grep train-ocr-detect-2 | awk '{print $1}')
docker rm -f   $(docker ps -a | grep train-ocr-detect-2 | awk '{print $1}')
docker rmi -f $(docker images | grep train-ocr-detect-2 | awk '{print $3}')

echo "START BUILD"
docker build --network=host -t train-ocr-detect-2 .

echo "START RUN"
docker run --restart=always --gpus '"device=1"' --net host -e TZ=Asia/Shanghai -d -p 8092:8092 \
-v /data:/data \
--name train-ocr-detect-2 train-ocr-detect-2:latest


