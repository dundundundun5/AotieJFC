service_name = "train-ocr-detect-2"
service_port = 8092

OBJECT_NAMES = ['CZ', 'CH']
