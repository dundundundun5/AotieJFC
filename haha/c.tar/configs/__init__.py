import os
import yaml


def init_config(cfg):
    with open(os.path.join("/data/weights", cfg), 'r') as f:
        conf = yaml.load(f.read(), Loader=yaml.Loader)

    return conf


config = init_config("TrainModelParam.json")
print(config)
