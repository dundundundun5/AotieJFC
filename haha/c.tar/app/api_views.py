import asyncio
import traceback
from io import BytesIO

import numpy as np
from PIL import Image
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import JSONResponse

from app.defect_detection import warmup_model, defect_detection_text
from app.log import logger
from configs.deploy_config import service_name

app = FastAPI(title=service_name)


@app.on_event("startup")
async def startup_event():
    loop = asyncio.get_running_loop()
    await loop.run_in_executor(None, warmup_model)


@app.get(f"/{service_name}/health")
async def health_check():
    return {
        'code': 200,
        'version': 1.0,
        'status': 'healthy'
    }


@app.post(f"/{service_name}/text/file")
async def defect_detection_handler(image_file: UploadFile = File(...)):
    try:
        try:
            image_bytes = await image_file.read()
            img = Image.open(BytesIO(image_bytes))
            img_array = np.array(img)
        except Exception as e:
            logger.error(f'Image processing error: {str(e)}')
            raise HTTPException(
                status_code=400,
                detail="Invalid image file or path"
            )

        height, width = img_array.shape[:2]
        loop = asyncio.get_running_loop()
        detection_result = await loop.run_in_executor(None, defect_detection_text, img_array, service_name)

        detection_result.setdefault('data', {})
        detection_result['data'].update({
            'imageWidth': width,
            'imageHeight': height
        })

        logger.info(f'Detected {len(detection_result["data"]["defectList"])} defects')
        return detection_result

    except HTTPException as he:
        raise
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}\n{traceback.format_exc()}")
        return JSONResponse(
            status_code=500,
            content={
                'code': 500,
                'message': 'Internal server error',
                'detail': str(e)
            }
        )
