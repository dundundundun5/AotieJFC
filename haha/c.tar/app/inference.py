import random
import re

import numpy as np
import torch
from paddleocr import TextRecognition
from ultralytics import YOLO

from configs import config

# 客车
PT = [
    'YW',
    'RW',
    'CA',
    'YZ',
    'KD',
    'XL',
    'ZE',
    'ZEC',
    'WE',
    'WY'
]

# 货车
FT = [
    'C',
    'X',
    'JSQ',
    'NX',
    'PB',
    'P',
    'GQ',
    'G',
    'GH',
    'GL',
    'GLBK',
    'DF',
    'T',
    'BH',
    'BDL',
    'BX',
    'L',
    'U',
    'UZ',
    'BNX',
    'K',
    'SS',
    'HDX'
]


def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    try:
        import paddle
        paddle.seed(seed)
    except ImportError:
        pass


def clean_text(text):
    return re.sub(r'[^a-zA-Z0-9]', '', text)


def get_initial_letters(s):
    match = re.match(r'^[A-Z]+', s)
    return match.group(0) if match else ""


def process_cz_text(text):
    """针对CZ类别的专用文本处理"""
    text = text.upper()
    replacements = {
        'O': '0',
        'I': '1',
        'MX': 'NX',
        'T0': '70',
        'TC': '70',
        '7C': '70',
        '170': 'L70',
        'XS': 'X6',
        'XE': 'X6',
        'CS': 'C6',
        'US': 'U6',
        'JSG': 'JSQ',
        'JS0': 'JSQ',
        'JSQS': 'JSQ6',
        'JSQG': 'JSQ6',
        '13': 'B',
        # '701': '70E'
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text


def process_ch_text(text):
    """针对CH类别的专用文本处理"""
    text = text.upper()
    replacements = {
        'O': '0',
        'I': '1',
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text


class Inference(object):
    def __init__(self,
                 model_path: str,
                 input_size: tuple = (640, 640),
                 conf: float = 0.5,
                 iou: float = 0.3,
                 task: str = 'segment'):
        set_seed(42)
        self.model = YOLO(model=model_path, task=task)
        self.ocr = TextRecognition(model_name="PP-OCRv5_server_rec")
        self.input_size = input_size
        self.conf = conf
        self.iou = iou
        self.task = task

    def _process_results(self, result):
        if not hasattr(result, 'boxes'):
            return None

        best_defects = {}
        for box in result.boxes:
            cls = int(box.cls)
            conf = box.conf.item()

            if cls not in best_defects or conf > best_defects[cls]["defectScore"]:
                xyxy = box.xyxy.squeeze().tolist()
                x1, y1, x2, y2 = int(xyxy[0]), int(xyxy[1]), int(xyxy[2]), int(xyxy[3])
                best_defects[cls] = {
                    "xyxy": [x1, y1, x2, y2],
                    "defectScore": conf
                }
        return best_defects

    def _process_defects(self, image, result, best_defects):
        if not best_defects:
            return []

        crop_images = []
        defect_infos = []
        for cls, defect_info in best_defects.items():
            x1, y1, x2, y2 = defect_info["xyxy"]
            conf = defect_info["defectScore"]
            crop_img = image[y1:y2, x1:x2]
            if crop_img.size > 0:
                crop_images.append(crop_img)
                defect_infos.append({
                    "cls": cls,
                    "conf": conf,
                    "xyxy": [x1, y1, x2, y2]
                })

        defects = []
        if crop_images:
            set_seed(42)
            texts = self.ocr.predict(crop_images, batch_size=len(crop_images))
            for idx, text_result in enumerate(texts):
                info = defect_infos[idx]
                text = clean_text(text_result['rec_text']) if text_result else ""
                kind = ''
                if result.names[info["cls"]] == 'CZ':
                    text = process_cz_text(text)
                    letter = get_initial_letters(text)
                    kind = 'PT' if letter in PT else 'FT'
                else:
                    text = process_ch_text(text)

                defects.append({
                    "defectType": result.names[info["cls"]],
                    "defectContent": text,
                    "defectKind": kind,
                    "defectScore": round(info["conf"], 4),
                    "topLeft": {"x": info["xyxy"][0], "y": info["xyxy"][1]},
                    "bottomRight": {"x": info["xyxy"][2], "y": info["xyxy"][3]},
                })

        return defects

    def predict_det(self, image):
        set_seed(42)
        crop_image = image
        results = self.model(source=image, conf=self.conf, iou=self.iou,
                             imgsz=self.input_size, verbose=False)

        all_defects = []
        for result in results:
            best_defects = self._process_results(result)
            if best_defects is None:
                continue

            defects = self._process_defects(crop_image, result, best_defects)
            all_defects.extend(defects)

        torch.cuda.empty_cache()
        return all_defects

    def predict_seg(self, image):
        set_seed(42)
        crop_image = image.copy()
        results = self.model(source=image, conf=self.conf, iou=self.iou,
                             imgsz=self.input_size, verbose=False)

        all_defects = []
        for result in results:
            if not hasattr(result, 'boxes') or not hasattr(result, 'masks'):
                continue

            best_defects = self._process_results(result)
            if best_defects is None:
                continue

            defects = self._process_defects(crop_image, result, best_defects)
            all_defects.extend(defects)

        torch.cuda.empty_cache()
        return all_defects

    def __call__(self, image):
        if self.task == 'segment':
            return self.predict_seg(image)
        return self.predict_det(image)


class InferenceModelCache:
    instance = None


def get_inference_model():
    if InferenceModelCache.instance is None:
        InferenceModelCache.instance = Inference(
            model_path="/data/weights/train-ocr-segment-2.pt",
            input_size=(1280, 1280),
            conf=config.get('ocr_conf', 0.5),
            iou=config.get('ocr_iou', 0.05),
            task='segment'
        )
    return InferenceModelCache.instance
