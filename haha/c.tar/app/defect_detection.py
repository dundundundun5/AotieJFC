import numpy as np

from app.inference import get_inference_model
from configs.deploy_config import service_name

# 预定义的字符串映射规则
REPLACEMENTS = {
    'B23': 'B2S',
    'EDL1': 'BDL1',
    'BDL': 'BDL1',
    'EDL': 'BDL1',
    'BD1L1': 'BDL1',
    'BD11': 'BDL1',
    'BD1L': 'BDL1',
    'ENX17K': 'BNX17K',
    '1BGW70': 'BGW70',
    'BX0B': 'BX70B',

    'C0': 'C70',
    'C7': 'C70',
    '0R0': 'C70',
    'CT': 'C70',
    'C623K': 'C62BK',
    'CK': 'C64K',
    '664K': 'C64K',
    '064K': 'C64K',
    'C64KK': 'C64K',
    'C0LK': 'C64K',
    'C04K': 'C64K',
    'C6AK': 'C64K',
    'CC4K': 'C64K',
    'C61K': 'C64K',
    'CSAK': 'C64K',
    'CEAK': 'C64K',
    'CGAK': 'C64K',
    'CG4K': 'C64K',
    'CE1K': 'C64K',
    'C6411': 'C64H',
    'C64H1': 'C64H',
    '664H': 'C64H',
    'C641': 'C64H',
    'C70E11': 'C70EH',
    'C7011': 'C70H',
    'C70E1H': 'C70EH',
    'C70E1': 'C70EH',
    'C70FH': 'C70EH',
    'CR0EH': 'C70EH',
    'CR0E': 'C70E',
    '070E': 'C70E',
    'CY0E': 'C70E',
    '670E': 'C70E',
    'C70EE': 'C70E',
    'CR0': 'C70',
    '070': 'C70',
    '670': 'C70',
    'G70': 'C70',
    'G70H': 'C70H',
    '070H': 'C70H',
    'G64H': 'C64H',
    'CA250': 'CA25G',
    'CA258': 'CA25B',
    'C703': 'C70E',
    'C7RE': 'C70E',
    'G70E': 'C70E',
    'CV0E': 'C70E',
    'G64K': 'C64K',
    'C84K': 'C64K',

    'G1BK': 'GLBK',
    'G173K': 'G17BK',

    'HX1': 'HXD',
    'H1XD': 'HXD',
    'HX': 'HXD',
    'HXB': 'HXD',

    'JSQ': 'JSQ6',
    'J8Q6': 'JSQ6',
    'J3Q6': 'JSQ6',
    'JSQE': 'JSQ6',
    'JSQE6': 'JSQ6',
    'JSQB': 'JSQ6',
    'JSQES': 'JSQ6',

    'K3NK': 'K13NK',

    'NX7': 'NX70',
    'NXZ0A': 'NX70A',
    'NX70N': 'NX70A',
    'HX70A': 'NX70A',
    'NX70AR': 'NX70AF',
    'NX173K': 'NX17BK',
    'NX7CA': 'NX70A',
    'NX171BK': 'NX17BK',
    'NX17B3K': 'NX17BK',
    'NX17B11': 'NX17BH',
    'NX178H': 'NX17BH',

    'E4AK': 'P64K',
    'PEAX': 'P64K',
    'PS4K': 'P64K',
    '164K': 'P64K',
    '1S4K': 'P64K',
    'P84GK': 'P64GK',
    'P62NDK': 'P62NK',
    'P620NK': 'P62NK',
    'P62N0K': 'P62NK',
    'PS2NK': 'P62NK',
    'P6ANK': 'P62NK',
    'F64GK': 'P64GK',
    'F64AK': 'P64AK',
    'PS4AK': 'P64AK',
    'P4AK': 'P64AK',
    'P61AK': 'P64AK',
    'F64K': 'P64K',
    'F70': 'P70',
    'P7': 'P70',
    'P1': 'PB',
    'PR': 'PB',

    'RW250': 'RW25G',
    'RW256': 'RW25G',
    'RW255': 'RW25G',
    'RW251': 'RW25G',

    'SSG': 'SS9',

    'T1BK': 'T11BK',
    'TBK': 'T11BK',
    'THBK': 'T11BK',

    'XL251': 'XL25T',
    'XL250': 'XL25G',
    'X6SK': 'X6K',
    'X6SBK': 'X6BK',
    'X6S1BK': 'X6BK',
    'X6BB': 'X6BK',
    'XGBK': 'X6BK',
    'XBK': 'X6BK',
    'X61BK': 'X6BK',
    'X0': 'X70',
    'X7': 'X70',
    'X700': 'X70',

    'YW250': 'YW25G',
    'YW256': 'YW25G',
    'YWA5G': 'YW25G',
    'YW25S': 'YW25G',
    'YWR5G': 'YW25G',
    'YW26G': 'YW25G',
    'YW251': 'YW25T',
    'YZ250': 'YZ25G',
    'VZ25G': 'YZ25G',
    'YZ25C': 'YZ25G',
    'YZ255': 'YZ25G',

    'Z': 'ZE',
}


def warmup_model():
    inference = get_inference_model()
    inference(np.zeros((640, 640, 3), dtype=np.uint8))


def get_defect_by_type(defects, defect_type=''):
    return next((d for d in defects if d['defectType'] == defect_type), None)


def _normalize_cz(cz, ch):
    # 基于CH首字符的特殊处理
    if cz in {'70', 'L70'}:
        if ch and ch[0] == '5': return 'X70'
        if ch and ch[0] == '1': return 'C70'
        if ch and ch[0] == '3': return 'P70'
        return cz

    # 使用映射表
    if cz in REPLACEMENTS:
        return REPLACEMENTS[cz]

    return cz


def _normalize_ch(cz, ch):
    if not ch:
        return ch

    # 规则1: HXD类型且末尾为1的7位编码
    if cz == 'HXD' and len(ch) == 7 and ch.endswith('1'):
        return ch[:-1]

    # 规则2: 第3位为7的8位编码
    if len(ch) >= 8 and ch[2] == '7':
        return ch[:2] + ch[3:8]

    # 规则3: X开头车型且首字符为6的7位编码
    if cz.startswith('X') and len(ch) == 7 and ch.startswith('6'):
        return '5' + ch[1:]

    if cz in {'C70E', 'C64K'} and len(ch) == 6:
        return ch[:1] + '8' + ch[1:]

    return ch


def _process_defects(defects):
    """处理缺陷列表的标准化"""
    defect_cz = get_defect_by_type(defects, 'CZ')
    defect_ch = get_defect_by_type(defects, 'CH')

    if defect_cz and defect_ch:
        cz_content = defect_cz['defectContent']
        ch_content = defect_ch['defectContent']

        # 执行标准化流程
        normalized_cz = _normalize_cz(cz_content, ch_content)
        normalized_ch = _normalize_ch(normalized_cz, ch_content)

        defect_cz['defectContent'] = normalized_cz
        defect_ch['defectContent'] = normalized_ch

    return defects


def defect_detection_text(img, model_name):
    ori_h, ori_w = img.shape[:2]
    defects = []

    try:
        if model_name != service_name:
            raise ValueError(f"Invalid service name: {model_name}")

        inference = get_inference_model()
        defects = inference(img)
        defects = _process_defects(defects)

        return {
            'code': 200,
            'data': {
                'imageWidth': ori_w,
                'imageHeight': ori_h,
                'defectList': defects,
            }
        }
    except Exception as e:
        return {
            "code": 500,
            "message": str(e),
            "data": {
                "imageWidth": ori_w,
                "imageHeight": ori_h,
                "defectList": defects,
            }
        }
