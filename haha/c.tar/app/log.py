# -*- coding:utf-8 -*-
import os
from loguru import logger

os.makedirs("logs", exist_ok=True)
logger.add("logs/app-process.log",
           level="INFO",
           rotation="00:00",
           retention="7 days",
           format="{time} - {level} - {message}",
           encoding="utf-8")

logger.add("logs/app-error.log",
           level="ERROR",
           rotation="00:00",
           retention="7 days",
           format="{time} - {level} - {message}",
           encoding="utf-8")

__all__ = ['logger']
