import uvicorn

from app.api_views import app
from configs.deploy_config import service_port

if __name__ == "__main__":
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=service_port,
        workers=1
    )

# uvicorn run:app --host 0.0.0.0 --port 8092 --workers 2
